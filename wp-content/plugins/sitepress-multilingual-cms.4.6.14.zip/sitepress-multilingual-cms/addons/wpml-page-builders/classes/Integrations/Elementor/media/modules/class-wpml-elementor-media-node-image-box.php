<?php

class WPML_Elementor_Media_Node_Image_Box extends WPML_Elementor_Media_Node_With_Image_Property {

	protected function get_property_name() {
		return 'image';
	}
}
