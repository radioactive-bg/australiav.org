<?php

class WPML_Cornerstone_Media_Node_Classic_Feature_Box extends WPML_Cornerstone_Media_Node_With_URLs {

	protected function get_keys() {
		return array(
			'graphic_image',
		);
	}
}
