jQuery(function () {
    var boxPopulation = new WpmlTpPollingPickupPopulateAction(jQuery, TranslationProxyPolling);
    boxPopulation.run();
});