<?php

class WPML_TM_Wizard_Options {
	const CURRENT_STEP                = 'WPML_TM_Wizard_For_Manager_Current_Step';
	const WIZARD_COMPLETE_FOR_MANAGER = 'WPML_TM_Wizard_For_Manager_Complete';
	const WIZARD_COMPLETE_FOR_ADMIN   = 'WPML_TM_Wizard_For_Admin_Complete';
	const WHO_WILL_TRANSLATE_MODE     = 'WPML_TM_Wizard_Who_Mode';
	const ONLY_I_USER_META            = 'WPML_TM_Wizard_Only_I';
}
